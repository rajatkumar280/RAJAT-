
function showRegister() {
  document.getElementById('form-section').style.display = 'block';
  document.getElementById('register-form').style.display = 'block';
  document.getElementById('login-form').style.display = 'none';
}
function showLogin() {
  document.getElementById('form-section').style.display = 'block';
  document.getElementById('login-form').style.display = 'block';
  document.getElementById('register-form').style.display = 'none';
}
function showIntro() {
  document.getElementById('form-section').style.display = 'none';
  document.getElementById('intro').style.display = 'block';
}
function showPlans() {
  document.getElementById('intro').style.display = 'none';
  document.getElementById('plans').style.display = 'block';
}
function showDashboard() {
  document.getElementById('plans').style.display = 'none';
  document.getElementById('dashboard').style.display = 'block';
}
